package softuni.exam.models.entities;

public enum Rating {
    GOOD, BAD, UNKNOWN
}
