package softuni.exam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import softuni.exam.models.entities.Car;

//ToDo
public interface CarRepository extends JpaRepository<Car, Integer> {

}
